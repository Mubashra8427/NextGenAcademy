package com.nextgenacademy.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.nextgenacademy.app.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NextGenAcademyTheme { AcademyApp() } }
    }
}

private data class NavItem(val route: String, val title: String, val icon: ImageVector)

@Composable
fun AcademyApp() {
    val nav = rememberNavController()
    var loggedIn by remember { mutableStateOf(false) }
    var studentName by remember { mutableStateOf("") }
    var studentMobile by remember { mutableStateOf("") }
    var studentClass by remember { mutableStateOf("Class 10") }
    var splash by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1200)
        splash = false
    }

    if (splash) {
        SplashScreen()
    } else if (!loggedIn) {
        WelcomeScreen(
            onLogin = { name, mobile, selectedClass ->
                studentName = name
                studentMobile = mobile
                studentClass = selectedClass
                loggedIn = true
            }
        )
    } else {
        val items = listOf(
            NavItem("home", "Home", Icons.Default.Home),
            NavItem("classes", "Classes", Icons.Default.MenuBook),
            NavItem("live", "Live", Icons.Default.LiveTv),
            NavItem("tests", "Tests", Icons.Default.Quiz),
            NavItem("profile", "Profile", Icons.Default.Person)
        )
        val entry by nav.currentBackStackEntryAsState()
        val route = entry?.destination?.route

        Scaffold(
            bottomBar = {
                NavigationBar {
                    items.forEach { item ->
                        NavigationBarItem(
                            selected = route == item.route,
                            onClick = {
                                nav.navigate(item.route) {
                                    launchSingleTop = true
                                    popUpTo("home") { saveState = true }
                                }
                            },
                            icon = { Icon(item.icon, item.title) },
                            label = { Text(item.title) }
                        )
                    }
                }
            }
        ) { pad ->
            NavHost(
                navController = nav,
                startDestination = "home",
                modifier = Modifier.padding(pad)
            ) {
                composable("home") { HomeScreen(nav, studentName, studentClass) }
                composable("classes") { ClassesScreen(studentClass) }
                composable("live") { LiveScreen(studentClass) }
                composable("tests") { TestsScreen(studentClass) }
                composable("profile") {
                    ProfileScreen(
                        name = studentName,
                        mobile = studentMobile,
                        studentClass = studentClass,
                        onLogout = { loggedIn = false }
                    )
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        Modifier.fillMaxSize().background(NavyBlue),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NextGen", color = Color.White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Text("Academy", color = AccentYellow, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp))
            Text("Learn. Grow. Succeed.", color = Color.White)
        }
    }
}

@Composable
fun WelcomeScreen(onLogin: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var selectedClass by remember { mutableStateOf("Class 10") }
    var expanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    val classes = listOf("Class 6", "Class 7", "Class 8", "Class 9", "Class 10")

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(vertical = 28.dp)
    ) {
        item {
            Text("NextGen Academy", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = NavyBlue)
            Spacer(Modifier.height(4.dp))
            Text("Online Tuition • Classes 6–10", style = MaterialTheme.typography.titleMedium)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SkyLight)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("Student Login", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Enter your details to open your learning dashboard.")
                }
            }
        }

        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it; error = "" },
                label = { Text("Student Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            OutlinedTextField(
                value = mobile,
                onValueChange = { mobile = it.filter(Char::isDigit).take(10); error = "" },
                label = { Text("Mobile Number") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Box(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { expanded = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(selectedClass)
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Select class")
                    }
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    classes.forEach { cls ->
                        DropdownMenuItem(
                            text = { Text(cls) },
                            onClick = {
                                selectedClass = cls
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        item {
            if (error.isNotEmpty()) {
                Text(error, color = MaterialTheme.colorScheme.error)
            }
        }

        item {
            Button(
                onClick = {
                    when {
                        name.trim().isEmpty() -> error = "Please enter student name."
                        mobile.length != 10 -> error = "Please enter a valid 10-digit mobile number."
                        else -> onLogin(name.trim(), mobile, selectedClass)
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Login / Continue", style = MaterialTheme.typography.titleMedium)
            }
        }

        item {
            Text(
                "Mathematics • Science • Social Science\nRegular Tests • Expert Faculty • Recorded Lectures",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun HomeScreen(nav: NavHostController, name: String, studentClass: String) {
    val displayName = name.ifBlank { "Student" }
    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Text("Good Morning, $displayName! 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SkyLight), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text(studentClass, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Your learning dashboard", color = TextSecondary)
                }
            }
        }
        item { SectionTitle("Quick Actions") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Join Live", Icons.Default.LiveTv) { nav.navigate("live") }
                ActionCard("Take Test", Icons.Default.Quiz) { nav.navigate("tests") }
            }
        }
        item { SectionTitle("Subjects") }
        items(listOf("Mathematics", "Science", "Social Science")) { subject -> SubjectCard(subject) }
        item { SectionTitle("Features") }
        item { Text("✓ Regular Tests\n✓ Expert Faculty\n✓ Recorded lectures if you miss a class\n✓ Study from anywhere", style = MaterialTheme.typography.bodyLarge) }
    }
}

@Composable fun ClassesScreen(studentClass: String) { SimpleListScreen("My Classes", listOf("$studentClass Mathematics", "$studentClass Science", "$studentClass Social Science"), Icons.Default.MenuBook) }
private data class LiveClassInfo(
    val subject: String,
    val time: String,
    val roomName: String
)

@Composable
fun LiveScreen(studentClass: String) {
    val context = LocalContext.current
    val classNumber = studentClass.removePrefix("Class ").trim()
    val liveClasses = listOf(
        LiveClassInfo("Mathematics", "Live classroom", "NextGenAcademy-Class${classNumber}-Mathematics"),
        LiveClassInfo("Science", "Live classroom", "NextGenAcademy-Class${classNumber}-Science"),
        LiveClassInfo("Social Science", "Live classroom", "NextGenAcademy-Class${classNumber}-SocialScience")
    )

    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            Text("Live Classes", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("Join your ${studentClass} online classroom", color = TextSecondary)
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SkyLight)
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("How it works", fontWeight = FontWeight.Bold)
                    Text("Tap Join Live to open the classroom. Your teacher can use the same room link to start the class.")
                }
            }
        }
        items(liveClasses) { liveClass ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.LiveTv, contentDescription = null, tint = LightBlue)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(liveClass.subject, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(liveClass.time, color = TextSecondary)
                    }
                    Button(onClick = {
                        val url = "https://meet.jit.si/${liveClass.roomName}"
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    }) {
                        Text("Join Live")
                    }
                }
            }
        }
    }
}
@Composable fun TestsScreen(studentClass: String) { SimpleListScreen("Tests", listOf("Mathematics — Practice Test", "Science — Chapter Test", "Social Science — Revision Test"), Icons.Default.Quiz) }

@Composable
fun ProfileScreen(name: String, mobile: String, studentClass: String, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("My Profile", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(name.ifBlank { "Student" }, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(studentClass)
                Text(if (mobile.isBlank()) "" else mobile)
                Text("NextGen Academy")
            }
        }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
    }
}

@Composable
fun SimpleListScreen(title: String, entries: List<String>, icon: ImageVector) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        items(entries) { entry -> ListCard(entry, icon) }
    }
}

@Composable
fun ListCard(text: String, icon: ImageVector) {
    Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = LightBlue)
            Spacer(Modifier.width(14.dp))
            Text(text, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable fun SubjectCard(subject: String) { ListCard(subject, Icons.Default.School) }
@Composable fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = NavyBlue) }

@Composable
fun RowScope.ActionCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.weight(1f).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = LightBlue)
            Spacer(Modifier.height(8.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}
