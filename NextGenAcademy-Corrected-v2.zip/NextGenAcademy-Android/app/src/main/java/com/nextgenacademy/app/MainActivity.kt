package com.nextgenacademy.app

import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import com.nextgenacademy.app.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NextGenAcademyTheme { AcademyApp() } }
    }
}

private data class NavItem(val route: String, val title: String, val icon: ImageVector)

@Composable
fun AcademyApp() {
    val nav = rememberNavController()
    var loggedIn by remember { mutableStateOf(false) }
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(1200); splash = false }

    if (splash) SplashScreen() else if (!loggedIn) {
        WelcomeScreen(onLogin = { loggedIn = true })
    } else {
        val items = listOf(
            NavItem("home", "Home", Icons.Default.Home),
            NavItem("classes", "Classes", Icons.Default.MenuBook),
            NavItem("live", "Live", Icons.Default.LiveTv),
            NavItem("tests", "Tests", Icons.Default.Quiz),
            NavItem("profile", "Profile", Icons.Default.Person)
        )
        val entry by nav.currentBackStackEntryAsState()
        val route = entry?.destination?.route
        Scaffold(bottomBar = {
            NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = route == item.route,
                        onClick = { nav.navigate(item.route) { launchSingleTop = true; popUpTo("home") { saveState = true } } },
                        icon = { Icon(item.icon, item.title) }, label = { Text(item.title) }
                    )
                }
            }
        }) { pad ->
            NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                composable("home") { HomeScreen(nav) }
                composable("classes") { ClassesScreen() }
                composable("live") { LiveScreen() }
                composable("tests") { TestsScreen() }
                composable("profile") { ProfileScreen(onLogout = { loggedIn = false }) }
            }
        }
    }
}

@Composable fun SplashScreen() {
    Box(Modifier.fillMaxSize().background(NavyBlue), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("NextGen", color = Color.White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Text("Academy", color = AccentYellow, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(10.dp)); Text("Learn. Grow. Succeed.", color = Color.White)
        }
    }
}

@Composable fun WelcomeScreen(onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("NextGen Academy", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = NavyBlue)
        Spacer(Modifier.height(12.dp)); Text("Quality Online Tuition for Classes 6–10", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(20.dp)); Text("Mathematics • Science • Social Science", color = LightBlue)
        Spacer(Modifier.height(32.dp)); Button(onClick = onLogin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("Login / Continue") }
        Spacer(Modifier.height(12.dp)); Text("Regular Tests • Expert Faculty • Recorded Lectures for Missed Classes", style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable fun HomeScreen(nav: NavHostController) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("Good Morning! 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Card(colors = CardDefaults.cardColors(containerColor = SkyLight), shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(20.dp)) { Text("Class 10", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("Your learning dashboard", color = TextSecondary) } } }
        item { SectionTitle("Quick Actions") }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { ActionCard("Join Live", Icons.Default.LiveTv) { nav.navigate("live") }; ActionCard("Take Test", Icons.Default.Quiz) { nav.navigate("tests") } } }
        item { SectionTitle("Subjects") }
        items(listOf("Mathematics", "Science", "Social Science")) { subject -> SubjectCard(subject) }
        item { SectionTitle("Features") }
        item { Text("✓ Regular Tests\n✓ Expert Faculty\n✓ Recorded lectures if you miss a class\n✓ Study from anywhere", style = MaterialTheme.typography.bodyLarge) }
    }
}

@Composable fun ClassesScreen() { SimpleListScreen("My Classes", listOf("Class 10 Mathematics", "Class 10 Science", "Class 10 Social Science"), Icons.Default.MenuBook) }
@Composable fun LiveScreen() { SimpleListScreen("Live Classes", listOf("Mathematics — Upcoming", "Science — Upcoming", "Social Science — Upcoming"), Icons.Default.LiveTv) }
@Composable fun TestsScreen() { SimpleListScreen("Tests", listOf("Mathematics — Practice Test", "Science — Chapter Test", "Social Science — Revision Test"), Icons.Default.Quiz) }

@Composable fun ProfileScreen(onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("My Profile", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(20.dp)) { Text("Student", style = MaterialTheme.typography.titleLarge); Text("Class 10"); Text("NextGen Academy") } }
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
    }
}

@Composable fun SimpleListScreen(title: String, entries: List<String>, icon: ImageVector) {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        items(entries) { entry -> ListCard(entry, icon) }
    }
}

@Composable fun ListCard(text: String, icon: ImageVector) { Card(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = LightBlue); Spacer(Modifier.width(14.dp)); Text(text, fontWeight = FontWeight.SemiBold) } } }
@Composable fun SubjectCard(subject: String) { ListCard(subject, Icons.Default.School) }
@Composable fun SectionTitle(text: String) { Text(text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = NavyBlue) }
@Composable fun ActionCard(title: String, icon: ImageVector, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = LightBlue); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.SemiBold) } } }
