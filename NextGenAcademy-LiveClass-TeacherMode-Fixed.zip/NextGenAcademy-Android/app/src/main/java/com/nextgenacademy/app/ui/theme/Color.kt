package com.nextgenacademy.app.ui.theme

import androidx.compose.ui.graphics.Color

// NextGen Academy Brand Colors
val NavyBlue = Color(0xFF0A192F)
val NavyDark = Color(0xFF020C1B)
val LightBlue = Color(0xFF0284C7)
val SkyBlue = Color(0xFF38BDF8)
val SkyLight = Color(0xFFE0F2FE)
val AccentYellow = Color(0xFFFBBF24)
val AmberAccent = Color(0xFFF59E0B)

val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFF8FAFC)
val CardBorder = Color(0xFFE2E8F0)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)
