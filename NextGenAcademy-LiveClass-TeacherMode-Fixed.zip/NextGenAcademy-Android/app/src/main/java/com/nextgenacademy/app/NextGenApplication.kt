package com.nextgenacademy.app

import android.app.Application

class NextGenApplication : Application()
