package com.nextgenacademy.app.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Welcome : Screen("welcome")
    object Login : Screen("login")
    object Register : Screen("register")
    object ForgotPassword : Screen("forgot_password")
    
    // Bottom Bar tabs
    object Home : Screen("home")
    object Classes : Screen("classes")
    object Live : Screen("live")
    object Tests : Screen("tests")
    object Profile : Screen("profile")
    
    // Additional screens
    object SubjectDetail : Screen("subject_detail/{subjectName}") {
        fun createRoute(subjectName: String) = "subject_detail/$subjectName"
    }
    object RecordedLectures : Screen("recorded_lectures")
    object Notes : Screen("notes")
    object TestTaking : Screen("test_taking/{testId}") {
        fun createRoute(testId: String) = "test_taking/$testId"
    }
    object Results : Screen("results")
    object Assignments : Screen("assignments")
    object Schedule : Screen("schedule")
    object Notifications : Screen("notifications")
    object HelpSupport : Screen("help_support")
    object About : Screen("about")
    object Settings : Screen("settings")
    object Admin : Screen("admin")
    object Teacher : Screen("teacher")
}
