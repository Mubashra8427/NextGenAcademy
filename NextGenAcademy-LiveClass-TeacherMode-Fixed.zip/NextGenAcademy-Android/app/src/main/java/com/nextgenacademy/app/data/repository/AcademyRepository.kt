package com.nextgenacademy.app.data.repository

import com.nextgenacademy.app.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Clean repository interface.
 * Implemented currently with structured local repository,
 * and architected so Firebase Firestore/Auth can be dropped in without changing UI code.
 */
interface AcademyRepository {
    val currentUser: Flow<User?>
    suspend fun login(email: String, pass: String): Result<User>
    suspend fun register(name: String, email: String, mobile: String, gradeClass: GradeClass, pass: String): Result<User>
    suspend fun logout()
    suspend fun switchRole(role: UserRole)
    
    fun getLiveClasses(gradeClass: GradeClass): Flow<List<LiveClass>>
    fun getRecordedLectures(gradeClass: GradeClass, subject: Subject? = null): Flow<List<RecordedLecture>>
    fun getNotes(gradeClass: GradeClass, subject: Subject? = null): Flow<List<NoteItem>>
    fun getTests(gradeClass: GradeClass): Flow<List<Test>>
    fun getResults(): Flow<List<TestResult>>
    fun getAssignments(gradeClass: GradeClass): Flow<List<Assignment>>
    fun getSchedule(gradeClass: GradeClass): Flow<List<ScheduleItem>>
    fun getNotifications(): Flow<List<AppNotification>>
    suspend fun submitTest(testId: String, userAnswers: Map<String, Int>): Result<TestResult>
    suspend fun submitAssignment(assignmentId: String, fileName: String): Result<Unit>
    suspend fun markNotificationRead(id: String)
}

class MockAcademyRepository : AcademyRepository {
    private val _currentUser = MutableStateFlow<User?>(
        User(
            id = "usr_01",
            name = "Ayaan Khan",
            email = "ayaan.khan@example.com",
            mobile = "+91 9876543210",
            role = UserRole.STUDENT,
            gradeClass = GradeClass.CLASS_10
        )
    )
    override val currentUser: Flow<User?> = _currentUser.asStateFlow()

    private val liveClasses = MutableStateFlow(
        listOf(
            LiveClass(
                id = "live_1",
                title = "Quadratic Equations Problem Set",
                subject = Subject.MATHEMATICS,
                gradeClass = GradeClass.CLASS_10,
                teacher = "Prof. Tariq Siddiqui",
                date = "Today",
                time = "05:00 PM - 06:15 PM",
                status = LiveStatus.LIVE,
                meetingUrl = "https://meet.google.com/nga-math-live"
            ),
            LiveClass(
                id = "live_2",
                title = "Light - Reflection & Ray Diagrams",
                subject = Subject.SCIENCE,
                gradeClass = GradeClass.CLASS_10,
                teacher = "Dr. Afzal Rahman",
                date = "Today",
                time = "06:45 PM - 08:00 PM",
                status = LiveStatus.UPCOMING,
                meetingUrl = "https://meet.google.com/nga-sci-live"
            )
        )
    )

    override suspend fun login(email: String, pass: String): Result<User> {
        val user = User(
            id = "usr_01",
            name = "Ayaan Khan",
            email = email,
            mobile = "+91 9389726160",
            role = UserRole.STUDENT,
            gradeClass = GradeClass.CLASS_10
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun register(name: String, email: String, mobile: String, gradeClass: GradeClass, pass: String): Result<User> {
        val user = User(
            id = "usr_new",
            name = name,
            email = email,
            mobile = mobile,
            role = UserRole.STUDENT,
            gradeClass = gradeClass
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun logout() {
        _currentUser.value = null
    }

    override suspend fun switchRole(role: UserRole) {
        val current = _currentUser.value ?: return
        _currentUser.value = current.copy(role = role)
    }

    override fun getLiveClasses(gradeClass: GradeClass) = liveClasses.asStateFlow()
    override fun getRecordedLectures(gradeClass: GradeClass, subject: Subject?) = MutableStateFlow(emptyList<RecordedLecture>()).asStateFlow()
    override fun getNotes(gradeClass: GradeClass, subject: Subject?) = MutableStateFlow(emptyList<NoteItem>()).asStateFlow()
    override fun getTests(gradeClass: GradeClass) = MutableStateFlow(emptyList<Test>()).asStateFlow()
    override fun getResults() = MutableStateFlow(emptyList<TestResult>()).asStateFlow()
    override fun getAssignments(gradeClass: GradeClass) = MutableStateFlow(emptyList<Assignment>()).asStateFlow()
    override fun getSchedule(gradeClass: GradeClass) = MutableStateFlow(emptyList<ScheduleItem>()).asStateFlow()
    override fun getNotifications() = MutableStateFlow(emptyList<AppNotification>()).asStateFlow()

    override suspend fun submitTest(testId: String, userAnswers: Map<String, Int>): Result<TestResult> {
        return Result.success(
            TestResult(
                id = "res_new",
                testId = testId,
                testTitle = "Completed Assessment",
                subject = Subject.MATHEMATICS,
                gradeClass = GradeClass.CLASS_10,
                dateTaken = "Today",
                totalMarks = 20,
                marksObtained = 18,
                percentage = 90,
                correctAnswers = 9,
                incorrectAnswers = 1,
                unanswered = 0
            )
        )
    }

    override suspend fun submitAssignment(assignmentId: String, fileName: String): Result<Unit> = Result.success(Unit)
    override suspend fun markNotificationRead(id: String) {}
}
