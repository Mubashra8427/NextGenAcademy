package com.nextgenacademy.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = LightBlue,
    onPrimary = SurfaceWhite,
    primaryContainer = SkyLight,
    onPrimaryContainer = NavyBlue,
    secondary = NavyBlue,
    onSecondary = SurfaceWhite,
    tertiary = AccentYellow,
    onTertiary = NavyDark,
    background = SurfaceLight,
    onBackground = TextPrimary,
    surface = SurfaceWhite,
    onSurface = TextPrimary,
    outline = CardBorder
)

@Composable
fun NextGenAcademyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
