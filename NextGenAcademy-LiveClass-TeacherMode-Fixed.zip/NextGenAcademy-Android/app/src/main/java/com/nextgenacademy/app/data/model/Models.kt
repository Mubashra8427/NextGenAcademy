package com.nextgenacademy.app.data.model

enum class GradeClass(val label: String) {
    CLASS_6("Class 6"),
    CLASS_7("Class 7"),
    CLASS_8("Class 8"),
    CLASS_9("Class 9"),
    CLASS_10("Class 10")
}

enum class Subject(val title: String) {
    MATHEMATICS("Mathematics"),
    SCIENCE("Science"),
    SOCIAL_SCIENCE("Social Science")
}

enum class UserRole {
    STUDENT,
    TEACHER,
    ADMIN
}

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val mobile: String = "",
    val role: UserRole = UserRole.STUDENT,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val enrolledSubjects: List<Subject> = listOf(Subject.MATHEMATICS, Subject.SCIENCE, Subject.SOCIAL_SCIENCE)
)

enum class LiveStatus { UPCOMING, LIVE, COMPLETED }

data class LiveClass(
    val id: String = "",
    val title: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val teacher: String = "",
    val date: String = "",
    val time: String = "",
    val status: LiveStatus = LiveStatus.UPCOMING,
    val meetingUrl: String = "",
    val recordingUrl: String? = null
)

data class RecordedLecture(
    val id: String = "",
    val title: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val chapter: String = "",
    val teacher: String = "",
    val duration: String = "",
    val date: String = "",
    val videoUrl: String = "",
    val thumbnail: String = "",
    val watchedPercentage: Int = 0
)

data class NoteItem(
    val id: String = "",
    val title: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val chapter: String = "",
    val fileType: String = "PDF",
    val fileSize: String = "",
    val date: String = "",
    val downloadUrl: String = "",
    val pages: Int = 0
)

data class TestQuestion(
    val id: String = "",
    val question: String = "",
    val options: List<String> = emptyList(),
    val correctOptionIndex: Int = 0,
    val explanation: String = ""
)

data class Test(
    val id: String = "",
    val title: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val chapter: String = "",
    val durationMinutes: Int = 30,
    val totalMarks: Int = 20,
    val startDate: String = "",
    val endDate: String = "",
    val questions: List<TestQuestion> = emptyList(),
    val isAvailable: Boolean = true
)

data class TestResult(
    val id: String = "",
    val testId: String = "",
    val testTitle: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val dateTaken: String = "",
    val totalMarks: Int = 20,
    val marksObtained: Int = 0,
    val percentage: Int = 0,
    val correctAnswers: Int = 0,
    val incorrectAnswers: Int = 0,
    val unanswered: Int = 0
)

enum class AssignmentStatus { PENDING, SUBMITTED, CHECKED }

data class Assignment(
    val id: String = "",
    val title: String = "",
    val subject: Subject = Subject.MATHEMATICS,
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val chapter: String = "",
    val dueDate: String = "",
    val instructions: String = "",
    val attachmentName: String? = null,
    val status: AssignmentStatus = AssignmentStatus.PENDING,
    val score: String? = null,
    val teacherFeedback: String? = null
)

data class ScheduleItem(
    val id: String = "",
    val day: String = "",
    val gradeClass: GradeClass = GradeClass.CLASS_10,
    val subject: Subject = Subject.MATHEMATICS,
    val time: String = "",
    val teacher: String = "",
    val meetingLink: String = ""
)

data class AppNotification(
    val id: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: String = "",
    val type: String = "general",
    val isRead: Boolean = false
)
