# NextGen Academy Android App

This is a corrected, exportable Android Studio project for NextGen Academy.

## Current version
- Native Kotlin + Jetpack Compose
- Material 3 UI
- Classes 6–10 scope
- Mathematics, Science, Social Science
- Student-facing Splash, Welcome, Home, Classes, Live, Tests and Profile screens
- Local/demo data only; no real authentication or Firebase credentials are included
- Firebase can be connected later without exposing credentials in the app

## Build in Android Studio
1. Extract this ZIP.
2. Open the `NextGenAcademy-Android` folder in Android Studio.
3. Allow Android Studio to sync Gradle and install any requested Android SDK components.
4. If Android Studio asks which JDK to use, select JDK 17.
5. Run the app on an emulator or connected Android phone.
6. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important
The project source is exportable and does not depend on an AI builder at runtime. Firebase is intentionally not configured because a `google-services.json` file contains project-specific configuration and should be created from the academy's own Firebase project.

The included demo login is a UI/demo flow only. Do not use it as production authentication.
